
document.addEventListener('DOMContentLoaded', function () {
  const searchInput = document.createElement('input');
  searchInput.placeholder = 'Search sensors...';
  searchInput.style.cssText = 'padding:10px;width:90%;margin:10px auto;display:block;background:#1e1e1e;color:#0ff;border:none;border-radius:5px;';
  document.body.insertBefore(searchInput, document.querySelector('main'));

  searchInput.addEventListener('input', function () {
    const query = this.value.toLowerCase();
    document.querySelectorAll('section').forEach(section => {
      const match = section.textContent.toLowerCase().includes(query);
      section.style.display = match ? 'block' : 'none';
    });
  });

  document.querySelectorAll('a.nav-link').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({ behavior: 'smooth' });
    });
  });
});
